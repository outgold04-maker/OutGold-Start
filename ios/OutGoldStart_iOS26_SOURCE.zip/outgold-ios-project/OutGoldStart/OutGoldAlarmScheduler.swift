import Foundation
import SwiftUI
import AlarmKit

/// iOS 26+ native alarm engine for the original OutGold Start UI.
/// Apple authorization and on-device verification are required before shipping.
struct OutGoldMetadata: AlarmMetadata { }

@MainActor
final class OutGoldAlarmScheduler {
    static let shared = OutGoldAlarmScheduler()
    private let manager = AlarmManager.shared
    private let defaults = UserDefaults.standard
    private let mappingKey = "outgold_ios_alarm_identifiers_v1"
    private let syncedKey = "outgold_ios_last_synchronized_v1"

    private init() { }

    func synchronize(json: String) async -> Bool {
        guard let data = json.data(using: .utf8),
              let list = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return false }
        let active = list.filter { ($0["enabled"] as? Bool ?? false) && ($0["id"] as? String) != nil }
        guard !active.isEmpty || defaults.string(forKey: syncedKey) != nil else { return true }

        if !active.isEmpty {
            do {
                guard try await manager.requestAuthorization() == .authorized else { return false }
            } catch { return false }
        }

        // No need to cancel/recreate a working alarm when only the view refreshed.
        if defaults.string(forKey: syncedKey) == json { return true }

        let saved = defaults.dictionary(forKey: mappingKey) as? [String: String] ?? [:]
        for raw in saved.values {
            if let id = UUID(uuidString: raw) { try? manager.cancel(id: id) }
        }

        var next: [String: String] = [:]
        var success = true
        for alarm in active {
            guard let originalID = alarm["id"] as? String,
                  let schedule = makeSchedule(alarm) else { success = false; continue }
            let id = UUID()
            let title = AlarmPresentation.Alert(title: "OutGold Start", stopButton: .stopButton, secondaryButton: nil, secondaryButtonBehavior: nil)
            let presentation = AlarmPresentation(alert: title)
            let attributes = AlarmAttributes(presentation: presentation,
                                             metadata: OutGoldMetadata(),
                                             tintColor: Color(red: 0.91, green: 0.70, blue: 0.25))
            let configuration = AlarmManager.AlarmConfiguration.alarm(
                schedule: schedule,
                attributes: attributes
            )
            do {
                _ = try await manager.schedule(id: id, configuration: configuration)
                next[originalID] = id.uuidString
            } catch {
                success = false
                print("OutGold AlarmKit scheduling failed: \(error)")
            }
        }
        defaults.set(next, forKey: mappingKey)
        if success { defaults.set(json, forKey: syncedKey) }
        return success
    }

    func scheduleShortTest() async -> Bool {
        do {
            guard try await manager.requestAuthorization() == .authorized else { return false }
            let alert = AlarmPresentation.Alert(title: "Teste OutGold Start", stopButton: .stopButton, secondaryButton: nil, secondaryButtonBehavior: nil)
            let attributes = AlarmAttributes(presentation: AlarmPresentation(alert: alert),
                                             metadata: OutGoldMetadata(), tintColor: .yellow)
            let config = AlarmManager.AlarmConfiguration.alarm(
                schedule: .fixed(Date().addingTimeInterval(15)), attributes: attributes
            )
            _ = try await manager.schedule(id: UUID(), configuration: config)
            return true
        } catch { return false }
    }

    private func makeSchedule(_ alarm: [String: Any]) -> Alarm.Schedule? {
        guard let time = alarm["time"] as? String else { return nil }
        let parts = time.split(separator: ":").compactMap { Int($0) }
        guard parts.count == 2, (0...23).contains(parts[0]), (0...59).contains(parts[1]) else { return nil }

        if let timestamp = alarm["oneTimeAt"] as? NSNumber, timestamp.doubleValue > 0 {
            let date = Date(timeIntervalSince1970: timestamp.doubleValue / 1000.0)
            return date > Date() ? .fixed(date) : nil
        }
        if let day = alarm["date"] as? String, !day.isEmpty {
            let parser = DateFormatter()
            parser.locale = Locale(identifier: "en_US_POSIX")
            parser.dateFormat = "yyyy-MM-dd HH:mm"
            if let date = parser.date(from: "\(day) \(time)") {
                return date > Date() ? .fixed(date) : nil
            }
        }
        let when = Alarm.Schedule.Relative.Time(hour: parts[0], minute: parts[1])
        let selectedDays = alarm["days"] as? [Int] ?? []
        let weekdays: [Locale.Weekday] = selectedDays.compactMap { day in
            switch day {
            case 0: return .sunday
            case 1: return .monday
            case 2: return .tuesday
            case 3: return .wednesday
            case 4: return .thursday
            case 5: return .friday
            case 6: return .saturday
            default: return nil
            }
        }
        return .relative(.init(time: when,
                               repeats: weekdays.isEmpty ? .never : .weekly(weekdays)))
    }
}
