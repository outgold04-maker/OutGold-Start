import SwiftUI

@main
struct OutGoldStartApp: App {
    var body: some Scene {
        WindowGroup {
            OutGoldWebView()
                .ignoresSafeArea()
                .preferredColorScheme(.dark)
        }
    }
}
