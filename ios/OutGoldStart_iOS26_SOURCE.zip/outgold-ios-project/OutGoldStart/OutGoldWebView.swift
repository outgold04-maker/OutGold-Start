import SwiftUI
import WebKit

/// Web UI is bundled from the approved OutGold Start 5D v5.1.6 Android HTML.
/// Native iOS alarms are handled by AlarmKit rather than JavaScript timers.
struct OutGoldWebView: UIViewRepresentable {
    func makeCoordinator() -> BridgeCoordinator { BridgeCoordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.websiteDataStore = .default()
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "outgoldBridge")
        controller.addUserScript(WKUserScript(
            source: Self.bridgeScript,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        ))
        configuration.userContentController = controller

        let view = WKWebView(frame: .zero, configuration: configuration)
        view.isOpaque = false
        view.backgroundColor = .black
        view.scrollView.backgroundColor = .black
        view.scrollView.contentInsetAdjustmentBehavior = .never
        context.coordinator.webView = view

        if let file = Bundle.main.url(forResource: "index", withExtension: "html") {
            view.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent())
        }
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) { }

    final class BridgeCoordinator: NSObject, WKScriptMessageHandler {
        weak var webView: WKWebView?

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard let data = message.body as? [String: Any],
                  let action = data["action"] as? String else { return }
            switch action {
            case "syncAlarms":
                guard let raw = data["alarms"] as? String else { return }
                Task { @MainActor in
                    let authorized = await OutGoldAlarmScheduler.shared.synchronize(json: raw)
                    // Report actual permission to the interface; never claim success in advance.
                    let status = "{\"exactAlarm\":\(authorized),\"notifications\":\(authorized),\"api\":\"iOS 26 AlarmKit\",\"fullScreen\":\(authorized),\"tts\":false}"
                    let jsonLiteral = String(data: try! JSONSerialization.data(withJSONObject: status, options: [.fragmentsAllowed]), encoding: .utf8)!
                    _ = try? await webView?.evaluateJavaScript("localStorage.setItem('outgold_native_status', \(jsonLiteral));")
                }
            case "testAlarm":
                Task { @MainActor in
                    let success = await OutGoldAlarmScheduler.shared.scheduleShortTest()
                    let messageText = success ? "Teste nativo marcado para daqui a 15 segundos." : "Não foi possível agendar o teste. Verifique a permissão de alarmes."
                    if let literal = String(data: (try? JSONSerialization.data(withJSONObject: messageText, options: [.fragmentsAllowed])) ?? Data(), encoding: .utf8) {
                        _ = try? await webView?.evaluateJavaScript("alert(\(literal));")
                    }
                }
            default:
                break
            }
        }
    }

    // Compatibility shim for the Android bridge expected by the approved interface.
    // Synchronous data is persisted in the WKWebView origin. Changes are sent to AlarmKit.
    private static let bridgeScript = #"""
    (function() {
      const bridge = (action, data) => {
        try { window.webkit.messageHandlers.outgoldBridge.postMessage(Object.assign({action}, data || {})); }
        catch (e) { console.warn('OutGold native bridge:', e); }
      };
      const json = (key, initial) => localStorage.getItem(key) || initial;
      window.NativeAlarm = {
        getAlarms: () => json('outgold_alarm_v1', '[]'),
        syncAlarms: (alarms) => { localStorage.setItem('outgold_alarm_v1', alarms); bridge('syncAlarms', {alarms}); },
        getSounds: () => json('outgold_ios_sounds', '[]'),
        saveSounds: (list) => localStorage.setItem('outgold_ios_sounds', list),
        getSlots: () => json('outgold_ios_slots', '{}'),
        saveSlot: (id, uri) => {
          const data = JSON.parse(json('outgold_ios_slots','{}'));
          data[id] = uri; localStorage.setItem('outgold_ios_slots', JSON.stringify(data));
        },
        removeSlot: (id) => {
          const data = JSON.parse(json('outgold_ios_slots','{}'));
          delete data[id]; localStorage.setItem('outgold_ios_slots', JSON.stringify(data));
        },
        getVoices: () => '[]',
        saveVoice: (s) => localStorage.setItem('outgold_ios_voice', s),
        saveLighting: (s) => localStorage.setItem('outgold_alarm_lighting_v1', s),
        setVacationUntil: (v) => localStorage.setItem('outgold_ios_vacation', v || ''),
        getStatus: () => json('outgold_native_status', '{"exactAlarm":false,"notifications":false,"api":"iOS 26 AlarmKit","fullScreen":false,"tts":false}'),
        testAlarm: () => bridge('testAlarm'),
        previewSound: () => {},
        stopPreview: () => {},
        pickSound: () => alert('Importação de áudio ainda não disponível nesta versão de desenvolvimento para iOS.'),
        speak: () => {},
        stopVoice: () => {},
        openFullScreenSettings: () => {}
      };
    })();
    """#
}
