# OutGold Start 5D — iOS 26+ (projeto de desenvolvimento)

**Status:** código-fonte inicial. **NÃO é um aplicativo iOS finalizado, compilado, assinado, nem aprovado para distribuição.**

## Objetivo

Preservar o HTML e a identidade visual **exatos** do OutGold Start Android 5D v5.1.6 aprovado, dentro de um aplicativo iOS nativo (`WKWebView`). O agendamento de alarmes é encaminhado a `AlarmKit` (iOS 26+), em vez de depender de timers do navegador, para permitir alertas do sistema com a tela bloqueada após autorização do usuário.

## Requisitos

- macOS com Xcode 26+ (ou um runner macOS compatível) e `xcodegen` instalado;
- iPhone com iOS 26 ou superior para testes de verdade;
- conta Apple Developer, certificados e perfis de assinatura para distribuir por TestFlight/App Store.

## Gerar o projeto no Mac

```sh
brew install xcodegen
xcodegen generate
open OutGoldStart.xcodeproj
```

No Xcode: selecione a equipe de assinatura, corrija o Bundle ID conforme sua conta, compile e teste no iPhone. O aplicativo pede autorização AlarmKit quando necessário.

## Funcionalidades e limitações nesta etapa

- Interface: HTML **original** da versão 5.1.6 incluído offline no app, com cores fixas, brilho e logotipo original;
- Alarmes: implementação inicial com AlarmKit para horários únicos e semanais;
- Importação de músicas, voz personalizada e sons específicos: **não implementados** no bridge iOS; alarme iOS usa som de sistema, não os 20 presets Android;
- Perfis avançados, adiamento, férias e integração de áudio devem ser revisados antes de distribuição;
- **Sem teste real de compilação/Xcode/iPhone nesta etapa**. Não disponibilizar comercialmente até aprovar funcionamento, alarmes com tela apagada, permissões e publicação Apple.

## Fonte de validação

Apple: https://developer.apple.com/documentation/AlarmKit/scheduling-an-alarm-with-alarmkit

OutGold Tecnologia. Não alterar a identidade visual original sem aprovação.
